<?php

//$con=mysqli_connect("localhost","root","","swaraj");

$con=mysqli_connect("localhost","meradaft_swaraj","MyPune@123","meradaft_swaraj");

?>